package com.example.laboratorio2

data class ExampleItem( val text1: String)
